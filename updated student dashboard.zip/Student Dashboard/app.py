from flask import Flask, render_template


#Create a Flask Instance
app = Flask(__name__)

#Create a route decorator
@app.route('/')

#def index():
   # return "<h1>Student Dashboard</h1>"
# localhost:5000/
def index():
    return render_template(index.html)
@app.route('/user/<name>')

def index(name):
    return "<h1>Student Dashboard {} </h1>".format(name)

